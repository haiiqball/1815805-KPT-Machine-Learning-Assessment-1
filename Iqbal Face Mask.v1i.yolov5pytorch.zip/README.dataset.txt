# Iqbal Face Mask > 2022-08-01 11:36am
https://universe.roboflow.com/object-detection/iqbal-face-mask

Provided by Roboflow
License: CC BY 4.0

